#pragma once
#include "GameObject.hpp"

class Brick : public GameObject
{
public:
    Brick(glm::vec3 position);
};

