#pragma once
#include "GameObject.hpp"

class Frame : public GameObject
{
public:
	Frame();
};

