#pragma once
#include "GameObject.hpp"

class Paddle : public GameObject
{
public:
	Paddle();
	virtual void update();
};

