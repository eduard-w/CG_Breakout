#include "Brick.hpp"

Brick::Brick(glm::vec3 position) : GameObject{ "cube.mesh", position, glm::vec3{1} }
{
}