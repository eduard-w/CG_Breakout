#include "Frame.hpp"

Frame::Frame() : GameObject{ "frame2.mesh", glm::vec3{0.0f}, glm::vec3{1} }
{

}